import { useEffect, useMemo, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth, GATEWAY_URL } from "./firebase/config";
import { completeMagicLink, login, loginGoogle, logout, register, resetPassword, sendMagicLink } from "./firebase/auth";
import { createRecord, listCollection, COLLECTIONS, getAdminProfile } from "./firebase/data";
import Icon from "./components/Icon";
import ModulePage from "./components/ModulePage";
import "./styles/app.css";

const nav = [
  ["Governance",[
    ["dashboard","Dashboard"],["members","Members"],["participants","Participants"],["meetings","Meetings"],
    ["meetingroom","Meeting Room"],["transcription","Transcription & Proceedings"],["resolutions","Resolutions"],
    ["voting","Voting"],["actions","Actions"],["documents","Documents"],["signatures","Signature Platform"],
    ["decisions","Decisions"],["risks","Risk Register"]
  ]],
  ["Finance",[["finance","Finance Portfolio"]]],
  ["Evidence",[["reports","Reports"],["audit","Audit Trail"]]],
  ["System",[["settings","Settings"]]]
];

function AuthScreen({member=false}){
  const [mode,setMode]=useState("login"),[email,setEmail]=useState(""),[password,setPassword]=useState(""),[name,setName]=useState(""),[status,setStatus]=useState(""),[busy,setBusy]=useState(false);
  async function go(e){
    e.preventDefault(); setBusy(true); setStatus("");
    try{
      if(mode==="login") await login(email,password);
      else if(mode==="register") await register(email,password);
      else await sendMagicLink(email);
      setStatus(mode==="magic"?"A secure sign-in link has been sent. Check your email.":"Signed in.");
    }catch(err){setStatus(err.message)}
    finally{setBusy(false)}
  }
  return <div className="auth-page"><div className="auth-card">
    <div className="auth-brand"><div className="seal">IRPA</div><div><b>IRPA</b><small>Digital Board Governance</small></div></div>
    <div className="auth-title"><h1>{member?"Member Gateway":"Administrator Gateway"}</h1><p>{member?"Secure access for Board members and authorised participants.":"Secure first-time administrator access."}</p></div>
    <form onSubmit={go} className="auth-form">
      {mode==="register" && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} required/></label>}
      <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></label>
      {mode!=="magic" && <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength={6}/></label>}
      <button className="btn primary wide" disabled={busy}>{busy?"Connecting…":mode==="magic"?"Send One-Time Administrator Link":mode==="register"?"Create Account":"Sign In"}</button>
    </form>
    {mode==="login" && <div className="auth-actions"><button className="link" onClick={()=>setMode("magic")}>Use one-time administrator link</button><button className="link" onClick={async()=>{try{await resetPassword(email);setStatus("Password reset email sent.")}catch(e){setStatus(e.message)}}}>Forgot password?</button></div>}
    {mode==="magic" && <button className="link" onClick={()=>setMode("login")}>Use email and password</button>}
    {mode==="login" && <button className="google" onClick={()=>loginGoogle()}>Continue with Google</button>}
    {mode==="login" && member && <button className="link" onClick={()=>setMode("register")}>New member? Create account</button>}
    {mode==="register" && <button className="link" onClick={()=>setMode("login")}>Back to sign in</button>}
    {status && <div className="alert">{status}</div>}
    <small className="auth-foot">Gateway: {GATEWAY_URL}</small>
  </div></div>
}

function Dashboard({setTab}){
  const [stats,setStats]=useState({members:0,meetings:0,actions:0,transcripts:0});
  useEffect(()=>{(async()=>{try{
    const [m,mt,a,t]=await Promise.all([listCollection("members"),listCollection("meetings"),listCollection("actions"),listCollection("transcriptions")]);
    setStats({members:m.length,meetings:mt.length,actions:a.length,transcripts:t.length});
  }catch{}})()},[]);
  return <section className="page">
    <div className="welcome"><div><span className="eyebrow">ADMIN CONTROL CENTRE</span><h2>IRPA Digital Board Governance System</h2><p>Integrated governance, meetings, secure voting, finance, records and reporting.</p></div><div className="role-card"><Icon name="shield"/><small>System Role</small><b>Administrator</b></div></div>
    <div className="stats">
      {[["members","Active Members"],["meetings","Meetings"],["actions","Open Actions"],["transcripts","Transcripts"]].map(([k,l])=><div className="stat" key={k}><span className="stat-icon"><Icon name={k}/></span><div><b>{stats[k]}</b><small>{l}</small></div></div>)}
    </div>
    <div className="grid-two">
      <div className="panel"><div className="panel-head"><div><h3>Governance Control Centre</h3><span>Master governance record relationships</span></div></div>
        <div className="notice"><b>The meeting is the master record.</b><br/>Attendance, room events, recordings, transcription, votes, resolutions and decisions are linked to their meetingId.</div>
        <div className="quick-grid">
          <button onClick={()=>setTab("members")}>＋ Add New Member</button><button onClick={()=>setTab("meetings")}>▣ Create Meeting</button>
          <button onClick={()=>setTab("documents")}>▱ Authorise Document</button><button onClick={()=>setTab("signatures")}>✎ Signature Platform</button>
        </div>
      </div>
      <div className="panel"><div className="panel-head"><div><h3>Security Architecture</h3><span>Production controls</span></div></div>
        <ul className="checks"><li>Firebase Authentication</li><li>Role-based Firestore Security Rules</li><li>Document-level authorization</li><li>Immutable audit records</li><li>Controlled member invitations</li><li>Signature and approval trail</li></ul>
      </div>
    </div>
  </section>
}

function Settings(){
  const [email,setEmail]=useState(auth.currentUser?.email||""); const [status,setStatus]=useState("");
  return <section className="page"><div className="page-head"><div><h2>System Settings</h2><p>Administrator account and platform configuration.</p></div></div>
    <div className="grid-two"><div className="panel"><h3>Administrator Account</h3><p className="muted">{email||"Authenticated administrator"}</p>
      <button className="btn" onClick={async()=>{try{await resetPassword(email);setStatus("Password reset email sent.")}catch(e){setStatus(e.message)}}}>Send Password Reset</button>{status&&<div className="alert">{status}</div>}
    </div><div className="panel"><h3>Firebase Configuration</h3><p>Project: <b>irpa-digital-governance-system</b></p><p>Gateway: <b>{GATEWAY_URL}</b></p><p>Google OAuth client is retained in <code>src/firebase/config.js</code>.</p></div></div>
  </section>
}

function AdminApp({user}){
  const [tab,setTab]=useState("dashboard"),[profile,setProfile]=useState({name:"Administrator",email:user.email||""});
  useEffect(()=>setProfile(p=>({...p,email:user.email||""})),[user]);
  const page = useMemo(()=>{
    if(tab==="dashboard") return <Dashboard setTab={setTab}/>;
    if(tab==="settings") return <Settings/>;
    const titles={
      members:["Board Members","Membership records, roles and status."],participants:["Participants","Meeting participants and invited stakeholders."],
      meetings:["Meetings","Meetings are the master governance record."],meetingroom:["Meeting Room","Live meeting events, attendance and proceedings."],
      transcription:["Transcription & Proceedings","Structured meeting transcription and proceedings."],resolutions:["Resolutions","Board resolutions and approval status."],
      voting:["Voting","Controlled votes linked to resolutions and meetings."],actions:["Open Actions","Action items, owners and due dates."],
      documents:["Documents","Governance documents and authorization status."],signatures:["Signature Platform","Document signature requests and completion trail."],
      decisions:["Decisions","Recorded board decisions and implementation status."],risks:["Risk Register","Governance and operational risk oversight."],
      finance:["Finance Portfolio","Financial oversight, budgets and transactions."],reports:["Reports","Governance and management reporting."],audit:["Audit Trail","Traceable governance activity and evidence."]
    };
    const [title,subtitle]=titles[tab]||["Module","Governance module"];
    return <ModulePage module={tab} title={title} subtitle={subtitle}/>;
  },[tab]);
  return <div className="app">
    <aside>
      <div className="brand"><div className="seal">IRPA</div><div><strong>IRPA</strong><small>DIGITAL BOARD GOVERNANCE</small></div></div>
      <div className="profile"><b>{profile.name}</b><span>{profile.email}</span><em>Administrator</em></div>
      <nav>{nav.map(([section,items])=><div key={section}><div className="nav-section">{section}</div>{items.map(([id,label])=><button key={id} className={tab===id?"active":""} onClick={()=>setTab(id)}><Icon name={id}/>{label}{id==="members"&&<span className="badge">•</span>}</button>)}</div>)}</nav>
      <div className="system-box"><b>System Information</b><span>Version 1.0.0</span><span>Environment Production</span><span>Status <i>● Online</i></span></div>
    </aside>
    <main>
      <div className="topbar"><div><b>IRPA Governance Gateway</b><small>Gateway URL: {GATEWAY_URL}</small></div><div className="top-actions"><button onClick={()=>setTab("members")}>Member Gateway ↗</button><button onClick={()=>location.reload()}>↻ Refresh</button><button className="danger" onClick={logout}>Sign out</button></div></div>
      <div className="content">{page}</div>
      <footer>Improvement of Rangeland in Pastoral Areas (IRPA) · Digital Board Governance System <span>Version 1.0.0</span></footer>
    </main>
  </div>
}

export default function App(){
  const [user,setUser]=useState(undefined),[profile,setProfile]=useState(undefined);
  useEffect(()=>{
    completeMagicLink().catch(()=>{});
    return onAuthStateChanged(auth,async current=>{
      setUser(current);
      if(current){ try{ setProfile(await getAdminProfile(current.uid)); }catch{ setProfile(null); } } else setProfile(null);
    });
  },[]);
  if(user===undefined || (user && profile===undefined)) return <div className="boot">Loading secure gateway…</div>;
  if(!user) return <AuthScreen member={false}/>;
  if(!profile || profile.active!==true) return <div className="auth-page"><div className="auth-card"><div className="auth-brand"><div className="seal">IRPA</div><div><b>IRPA</b><small>Digital Board Governance</small></div></div><div className="auth-title"><h1>Access Pending</h1><p>This account is authenticated, but it is not authorised for the Administrator Gateway.</p></div><div className="alert error">Contact the authorised IRPA administrator to activate your administrator profile.</div><button className="btn danger wide" onClick={logout}>Sign out</button></div></div>;
  return <AdminApp user={user}/>;
}