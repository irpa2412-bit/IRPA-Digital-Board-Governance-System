import { addDoc, collection, deleteDoc, doc, getDoc, getDocs, limit, orderBy, query, serverTimestamp, setDoc, updateDoc } from "firebase/firestore";
import { auth, db } from "./config";

export const COLLECTIONS = {
  members:"members", participants:"participants", meetings:"meetings", meetingSubscriptions:"meetingSubscriptions",
  meetingRoomEvents:"meetingRoomEvents", transcriptions:"transcriptions", resolutions:"resolutions", votes:"votes", voteLocks:"voteLocks",
  actions:"actions", documents:"documents", signatures:"signatures", decisions:"decisions", risks:"risks", audit:"audit", reports:"reports",
  financeBudgets:"financeBudgets", financeTransactions:"financeTransactions", financeFunding:"financeFunding", financeApprovals:"financeApprovals",
  financeCommitments:"financeCommitments", financeGrants:"financeGrants", financeBankAccounts:"financeBankAccounts", financeReconciliations:"financeReconciliations",
  financeAssets:"financeAssets", financeRisks:"financeRisks", financeReports:"financeReports", invitations:"invitations", adminProfiles:"adminProfiles", systemSettings:"systemSettings"
};

const actor = () => ({ uid: auth.currentUser?.uid || null, email: auth.currentUser?.email || null });
export async function listCollection(name, max=100) {
  const ref = collection(db,name);
  try { const snap = await getDocs(query(ref,orderBy("createdAt","desc"),limit(max))); return snap.docs.map(d=>({id:d.id,...d.data()})); }
  catch { const snap = await getDocs(query(ref,limit(max))); return snap.docs.map(d=>({id:d.id,...d.data()})); }
}
export async function getRecord(name,id) { const snap=await getDoc(doc(db,name,id)); return snap.exists()?{id:snap.id,...snap.data()}:null; }
export async function createRecord(name,data) {
  const ref=await addDoc(collection(db,name),{...data,createdAt:serverTimestamp(),updatedAt:serverTimestamp(),createdBy:actor().uid});
  if(name!=="audit") await writeAudit("CREATE",name,ref.id,{summary:`Created ${name}/${ref.id}`});
  return ref.id;
}
export async function setRecord(name,id,data) { await setDoc(doc(db,name,id),{...data,updatedAt:serverTimestamp()},{merge:true}); }
export async function updateRecord(name,id,data) { await updateDoc(doc(db,name,id),{...data,updatedAt:serverTimestamp()}); if(name!=="audit") await writeAudit("UPDATE",name,id,{summary:`Updated ${name}/${id}`}); }
export async function deleteRecord(name,id) { await deleteDoc(doc(db,name,id)); if(name!=="audit") await writeAudit("DELETE",name,id,{summary:`Deleted ${name}/${id}`}); }
export async function writeAudit(action,collectionName,recordId,extra={}) {
  await addDoc(collection(db,"audit"),{action,collection:collectionName,recordId,...extra,actorUid:actor().uid,actorEmail:actor().email,createdAt:serverTimestamp()});
}
export async function getAdminProfile(uid=auth.currentUser?.uid) { return uid ? getRecord("adminProfiles",uid) : null; }
