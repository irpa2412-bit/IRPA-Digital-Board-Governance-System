import {
  GoogleAuthProvider, createUserWithEmailAndPassword, sendPasswordResetEmail,
  sendSignInLinkToEmail, signInWithEmailAndPassword, signInWithPopup,
  signOut, updatePassword, isSignInWithEmailLink, signInWithEmailLink
} from "firebase/auth";
import { auth } from "./config";

export const googleProvider = new GoogleAuthProvider();

export const login = (email,password) => signInWithEmailAndPassword(auth,email,password);
export const loginGoogle = () => signInWithPopup(auth,googleProvider);
export const logout = () => signOut(auth);
export const register = (email,password) => createUserWithEmailAndPassword(auth,email,password);
export const resetPassword = email => sendPasswordResetEmail(auth,email);
export const changePassword = password => updatePassword(auth.currentUser,password);

export const sendMagicLink = async email => {
  const actionCodeSettings = {
    url: `${window.location.origin}/admin`,
    handleCodeInApp: true
  };
  await sendSignInLinkToEmail(auth,email,actionCodeSettings);
  window.localStorage.setItem("irpaAdminEmail",email);
};

export const completeMagicLink = async () => {
  if (!isSignInWithEmailLink(auth,window.location.href)) return null;
  let email = window.localStorage.getItem("irpaAdminEmail");
  if (!email) email = window.prompt("Confirm your email address");
  if (!email) throw new Error("Email is required to complete sign-in.");
  const result = await signInWithEmailLink(auth,email,window.location.href);
  window.localStorage.removeItem("irpaAdminEmail");
  return result;
};
