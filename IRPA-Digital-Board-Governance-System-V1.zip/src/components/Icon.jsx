export default function Icon({name}) {
  const icons = {
    dashboard:"⌂", members:"♟", participants:"◉", meetings:"▣", meetingroom:"●",
    transcription:"≡", resolutions:"▤", voting:"✓", actions:"☑", documents:"▱",
    signatures:"✎", decisions:"◆", risks:"⚠", finance:"▥", reports:"▤",
    audit:"◫", settings:"⚙", search:"⌕", refresh:"↻", logout:"↪", shield:"⬟"
  };
  return <span className="icon" aria-hidden="true">{icons[name] || "•"}</span>;
}