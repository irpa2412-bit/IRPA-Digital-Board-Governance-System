import { useEffect, useMemo, useState } from "react";
import { COLLECTIONS, createRecord, deleteRecord, listCollection } from "../firebase/data";

const schemas={
 members:["fullName","email","role","status"], participants:["name","organization","role","meetingId"], meetings:["title","date","venue","status"],
 meetingroom:["meetingId","event","actor","timestamp"], transcription:["meetingId","speaker","entry","status"], resolutions:["resolution","meetingId","status","owner"],
 voting:["resolutionId","meetingId","status","result"], actions:["action","owner","dueDate","status"], documents:["title","type","classification","status"],
 signatures:["documentId","signerUid","role","status"], decisions:["decision","meetingId","responsible","status"], risks:["risk","owner","likelihood","status"],
 finance:["budgetTitle","category","period","totalBudget"], reports:["report","period","status","owner"], audit:["actorEmail","action","collection","createdAt"]
};
const labels={fullName:"Full Name",email:"Email",role:"Role",status:"Status",name:"Name",organization:"Organization",meetingId:"Meeting ID",title:"Title",date:"Date",venue:"Venue",event:"Event",actor:"Actor",timestamp:"Timestamp",speaker:"Speaker",entry:"Proceedings Entry",resolution:"Resolution",owner:"Owner",resolutionId:"Resolution ID",result:"Result",action:"Action",dueDate:"Due Date",type:"Document Type",classification:"Classification",documentId:"Document ID",signerUid:"Signer UID",decision:"Decision",responsible:"Responsible",risk:"Risk",likelihood:"Likelihood",budgetTitle:"Budget Title",category:"Category",period:"Period",totalBudget:"Total Budget",report:"Report",actorEmail:"Actor Email",collection:"Collection",createdAt:"Timestamp"};

export default function ModulePage({module,title,subtitle}){
 const collection=COLLECTIONS[module==="transcription"?"transcriptions":module]||module; const fields=schemas[module]||["title","description","status"];
 const [rows,setRows]=useState([]),[form,setForm]=useState({}),[loading,setLoading]=useState(true),[error,setError]=useState(""),[saved,setSaved]=useState("");
 const load=async()=>{setLoading(true);setError("");try{setRows(await listCollection(collection))}catch(e){setError(e.message)}finally{setLoading(false)}};
 useEffect(()=>{load()},[collection]);
 const required=useMemo(()=>fields.filter(f=>["fullName","title","resolution","risk","action","decision","email"].includes(f)),[fields]);
 async function submit(e){e.preventDefault();setError("");setSaved("");try{await createRecord(collection,form);setForm({});setSaved("Saved successfully.");await load()}catch(e){setError(e.message)}}
 async function remove(id){if(!confirm("Delete this record?"))return;try{await deleteRecord(collection,id);await load()}catch(e){setError(e.message)}}
 return <section className="page"><div className="page-head"><div><h2>{title}</h2><p>{subtitle}</p></div><button className="btn" onClick={load}>↻ Refresh</button></div>
  <div className="grid-two"><div className="panel"><h3>Add {title.replace(/s$/i,"")}</h3><form onSubmit={submit} className="formgrid">
   {fields.filter(f=>module!=="audit"||f!=="createdAt").map(f=><label key={f}>{labels[f]||f}<input type={f.includes("Date")||f==="date"?"date":"text"} value={form[f]||""} onChange={e=>setForm({...form,[f]:e.target.value})} required={required.includes(f)}/></label>)}
   {saved&&<div className="alert">{saved}</div>}{error&&<div className="alert error">{error}</div>}<button className="btn primary" type="submit">Save Record</button>
  </form></div>
  <div className="panel"><div className="panel-head"><div><h3>{title} Records</h3><span>{rows.length} records</span></div></div>{loading?<div className="empty">Loading…</div>:rows.length===0?<div className="empty">No records recorded.</div>:
   <div className="table-wrap"><table><thead><tr>{fields.map(f=><th key={f}>{labels[f]||f}</th>)}{module!=="audit"&&<th>Actions</th>}</tr></thead><tbody>{rows.map(r=><tr key={r.id}>{fields.map(f=><td key={f}>{typeof r[f]==="object"&&r[f]?.toDate?r[f].toDate().toLocaleString():String(r[f]??"—")}</td>)}{module!=="audit"&&<td><button className="link danger-text" onClick={()=>remove(r.id)}>Delete</button></td>}</tr>)}</tbody></table></div>}
  </div></div></section>
}
